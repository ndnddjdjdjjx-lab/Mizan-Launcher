package com.mizan.launcher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load

/** Док-бар: до 5 закреплённых приложений, только иконки. */
class DockAdapter(
    private val onClick: (AppInfo, View) -> Unit,
    private val onLongClick: (AppInfo, View) -> Unit
) : ListAdapter<AppInfo, DockAdapter.VH>(AppDiff) {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_dock, parent, false)
        val vh = VH(v)
        v.setOnClickListener {
            val p = vh.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(getItem(p), v)
        }
        v.setOnLongClickListener {
            val p = vh.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onLongClick(getItem(p), v)
            true
        }
        return vh
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.icon.load(getItem(position).icon())
    }
}
