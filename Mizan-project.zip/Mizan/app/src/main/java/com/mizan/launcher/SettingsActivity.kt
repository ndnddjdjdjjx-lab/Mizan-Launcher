package com.mizan.launcher

import android.app.AlertDialog
import android.app.WallpaperManager
import android.app.admin.DevicePolicyManager
import android.app.role.RoleManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.max

class SettingsActivity : AppCompatActivity() {

    private lateinit var tvOverlay: TextView
    private lateinit var tvAdmin: TextView
    private lateinit var tvGlass: TextView
    private lateinit var tvCols: TextView
    private lateinit var accentRow: LinearLayout

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) chooseWallpaperTarget(uri)
    }
    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }

    private val accents = intArrayOf(
        0xFF7CC4FF.toInt(), 0xFFB794F6.toInt(), 0xFFFF8FA3.toInt(), 0xFFFFB86B.toInt(),
        0xFFFFE066.toInt(), 0xFF7EE787.toInt(), 0xFF5EEAD4.toInt(), 0xFFFFFFFF.toInt()
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_settings)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.settings_root)) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }

        tvOverlay = findViewById(R.id.tv_overlay)
        tvAdmin = findViewById(R.id.tv_admin)
        tvGlass = findViewById(R.id.tv_glass)
        tvCols = findViewById(R.id.tv_cols)
        accentRow = findViewById(R.id.accent_row)

        // ---- система ----
        findViewById<Button>(R.id.btn_default_launcher).setOnClickListener { requestDefaultLauncher() }

        // ---- разрешения ----
        findViewById<Button>(R.id.btn_overlay).setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        findViewById<Button>(R.id.btn_admin).setOnClickListener {
            startActivity(
                Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent())
                    .putExtra(
                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "Нужно только для блокировки экрана двойным тапом."
                    )
            )
        }

        // ---- обои ----
        findViewById<Button>(R.id.btn_wall_static).setOnClickListener { pickImage.launch("image/*") }
        findViewById<Button>(R.id.btn_wall_live).setOnClickListener {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e: Exception) {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Обои"))
            }
        }
        findViewById<Button>(R.id.btn_wall_system).setOnClickListener {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Обои"))
        }

        // ---- стекло ----
        val seekGlass = findViewById<SeekBar>(R.id.seek_glass)
        seekGlass.progress = Prefs.glassAlpha - 5
        tvGlass.text = "Прозрачность стекла: ${Prefs.glassAlpha}%"
        seekGlass.onChange { p ->
            Prefs.glassAlpha = p + 5
            tvGlass.text = "Прозрачность стекла: ${p + 5}%"
        }

        // ---- сетка ----
        val seekCols = findViewById<SeekBar>(R.id.seek_cols)
        seekCols.progress = Prefs.gridColumns - 3
        tvCols.text = "Колонок в сетке: ${Prefs.gridColumns}"
        seekCols.onChange { p ->
            Prefs.gridColumns = p + 3
            tvCols.text = "Колонок в сетке: ${p + 3}"
        }

        buildAccentRow()

        // ---- часы ----
        val spinClock = findViewById<Spinner>(R.id.spin_clock_style)
        spinClock.adapter = spinnerAdapter(ClockStyles.names.toList())
        spinClock.setSelection(Prefs.clockStyle.coerceIn(0, ClockStyles.names.size - 1))
        spinClock.onSelect { Prefs.clockStyle = it }

        findViewById<SwitchCompat>(R.id.sw_clock24).apply {
            isChecked = Prefs.clock24h
            setOnCheckedChangeListener { _, c -> Prefs.clock24h = c }
        }
        findViewById<SwitchCompat>(R.id.sw_date).apply {
            isChecked = Prefs.showDate
            setOnCheckedChangeListener { _, c -> Prefs.showDate = c }
        }

        // ---- погода ----
        val etCity = findViewById<EditText>(R.id.et_city)
        etCity.setText(Prefs.weatherCity)
        findViewById<Button>(R.id.btn_weather_refresh).setOnClickListener {
            Prefs.weatherCity = etCity.text.toString().trim()
            Prefs.weatherTime = 0L
            Toast.makeText(this, "Город сохранён, обновится на главном экране", Toast.LENGTH_SHORT).show()
        }

        // ---- меню приложений ----
        findViewById<SwitchCompat>(R.id.sw_drawer_grid).apply {
            isChecked = Prefs.drawerGrid
            setOnCheckedChangeListener { _, c -> Prefs.drawerGrid = c }
        }
        val spinSort = findViewById<Spinner>(R.id.spin_sort)
        spinSort.adapter = spinnerAdapter(listOf("По категориям", "По алфавиту"))
        spinSort.setSelection(if (Prefs.drawerByCategory) 0 else 1)
        spinSort.onSelect { Prefs.drawerByCategory = it == 0 }

        findViewById<Button>(R.id.btn_hidden).setOnClickListener { showHiddenDialog() }

        // ---- иконпак ----
        val packs = IconPacks.installed(this)
        val spinPack = findViewById<Spinner>(R.id.spin_iconpack)
        spinPack.adapter = spinnerAdapter(listOf("Системные иконки") + packs.map { it.label })
        val current = packs.indexOfFirst { it.pkg == Prefs.iconPack }
        spinPack.setSelection(if (current >= 0) current + 1 else 0)
        spinPack.onSelect { pos -> Prefs.iconPack = if (pos == 0) "" else packs[pos - 1].pkg }
    }

    override fun onResume() {
        super.onResume()
        tvOverlay.text = "Поверх других окон: " + if (Settings.canDrawOverlays(this)) "включено" else "выключено"
        val dpm = getSystemService(DevicePolicyManager::class.java)
        tvAdmin.text = "Блокировка экрана (Device Admin): " +
            if (dpm.isAdminActive(adminComponent())) "включено" else "выключено"
    }

    private fun adminComponent() = ComponentName(this, MizanDeviceAdmin::class.java)

    // ------------------------------------------------------------ рабочий стол по умолчанию

    private fun requestDefaultLauncher() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                return
            }
            if (rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                Toast.makeText(this, "Mizan уже рабочий стол по умолчанию", Toast.LENGTH_SHORT).show()
                return
            }
        }
        startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
    }

    // ------------------------------------------------------------ обои

    private fun chooseWallpaperTarget(uri: Uri) {
        AlertDialog.Builder(this)
            .setTitle("Куда поставить обои?")
            .setItems(arrayOf("Главный экран", "Экран блокировки", "Оба")) { _, which ->
                val flags = when (which) {
                    0 -> WallpaperManager.FLAG_SYSTEM
                    1 -> WallpaperManager.FLAG_LOCK
                    else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                }
                Toast.makeText(this, "Ставлю обои…", Toast.LENGTH_SHORT).show()
                Thread {
                    val ok = try {
                        val bmp = decodeScaled(uri)
                        WallpaperManager.getInstance(this).setBitmap(bmp, null, true, flags)
                        true
                    } catch (e: Exception) {
                        false
                    }
                    runOnUiThread {
                        Toast.makeText(this, if (ok) "Готово" else "Не удалось поставить обои", Toast.LENGTH_SHORT).show()
                    }
                }.start()
            }
            .show()
    }

    /** Уменьшаем картинку до размера экрана, чтобы не раздувать память на бюджетном устройстве. */
    private fun decodeScaled(uri: Uri): Bitmap {
        val dm = resources.displayMetrics
        val target = (max(dm.widthPixels, dm.heightPixels) * 1.3f).toInt()
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= target) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, opts) }!!
    }

    // ------------------------------------------------------------ акцент

    private fun buildAccentRow() {
        accentRow.removeAllViews()
        val size = dp(38f).toInt()
        val margin = dp(8f).toInt()
        for (c in accents) {
            val v = View(this)
            val d = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(c)
                if (c == Prefs.accent) setStroke(dp(3f).toInt(), Color.WHITE)
                else setStroke(dp(1f).toInt(), 0x55FFFFFF)
            }
            v.background = d
            v.layoutParams = LinearLayout.LayoutParams(size, size).apply { rightMargin = margin }
            v.setOnClickListener {
                Prefs.accent = c
                buildAccentRow()
            }
            accentRow.addView(v)
        }
    }

    // ------------------------------------------------------------ скрытые приложения

    private fun showHiddenDialog() {
        AppRepository.load(this) { all ->
            val hidden = Prefs.hidden.toMutableSet()
            val labels = all.map { it.label }.toTypedArray()
            val checked = BooleanArray(all.size) { all[it].key in hidden }
            AlertDialog.Builder(this)
                .setTitle("Скрытые приложения")
                .setMultiChoiceItems(labels, checked) { _, i, on ->
                    if (on) hidden.add(all[i].key) else hidden.remove(all[i].key)
                }
                .setPositiveButton("Готово") { _, _ -> Prefs.hidden = hidden }
                .setNegativeButton("Отмена", null)
                .show()
        }
    }

    // ------------------------------------------------------------ helpers

    private fun dp(v: Float) = resources.displayMetrics.density * v

    private fun spinnerAdapter(items: List<String>) =
        ArrayAdapter(this, android.R.layout.simple_spinner_item, items).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

    private fun SeekBar.onChange(block: (Int) -> Unit) {
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) block(p)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
    }

    /** Spinner дёргает слушатель один раз при показе — этот первый вызов пропускаем. */
    private fun Spinner.onSelect(block: (Int) -> Unit) {
        var first = true
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (first) {
                    first = false
                    return
                }
                block(pos)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }
}
