package com.mizan.launcher

import android.app.admin.DeviceAdminReceiver

/** Пустой ресивер: нужен только чтобы получить право DevicePolicyManager.lockNow(). */
class MizanDeviceAdmin : DeviceAdminReceiver()
