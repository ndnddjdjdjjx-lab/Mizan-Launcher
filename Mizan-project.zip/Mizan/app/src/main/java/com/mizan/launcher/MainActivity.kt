package com.mizan.launcher

import android.annotation.SuppressLint
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs
import kotlin.math.max

class MainActivity : AppCompatActivity() {

    private lateinit var root: View
    private lateinit var clockTime: TextClock
    private lateinit var clockDate: TextClock
    private lateinit var weatherCard: View
    private lateinit var weatherIcon: TextView
    private lateinit var weatherTemp: TextView
    private lateinit var weatherDesc: TextView
    private lateinit var notesCard: View
    private lateinit var notes: EditText
    private lateinit var homeGrid: RecyclerView
    private lateinit var dock: RecyclerView
    private lateinit var dockContainer: View
    private lateinit var hint: TextView

    private lateinit var homeAdapter: HomeGridAdapter
    private lateinit var dockAdapter: DockAdapter

    private val handler = Handler(Looper.getMainLooper())
    private val saveNote = Runnable { Prefs.note = notes.text.toString() }
    private val repoListener: () -> Unit = { bind() }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        clockTime = findViewById(R.id.clock_time)
        clockDate = findViewById(R.id.clock_date)
        weatherCard = findViewById(R.id.weather_card)
        weatherIcon = findViewById(R.id.weather_icon)
        weatherTemp = findViewById(R.id.weather_temp)
        weatherDesc = findViewById(R.id.weather_desc)
        notesCard = findViewById(R.id.notes_card)
        notes = findViewById(R.id.notes_edit)
        homeGrid = findViewById(R.id.home_grid)
        dock = findViewById(R.id.dock)
        dockContainer = findViewById(R.id.dock_container)
        hint = findViewById(R.id.hint)

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }

        homeAdapter = HomeGridAdapter(::onAppClick, ::onHomeLongClick)
        dockAdapter = DockAdapter(::onAppClick, ::onDockLongClick)

        homeGrid.layoutManager = GridLayoutManager(this, Prefs.gridColumns)
        homeGrid.adapter = homeAdapter
        homeGrid.itemAnimator = null
        homeGrid.setHasFixedSize(true)

        dock.layoutManager = GridLayoutManager(this, 4)
        dock.adapter = dockAdapter
        dock.itemAnimator = null

        weatherCard.setOnClickListener { refreshWeather(true) }

        notes.setText(Prefs.note)
        notes.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(saveNote)
                handler.postDelayed(saveNote, 600)
            }
        })

        // «Домой» не закрывает рабочий стол
        onBackPressedDispatcher.addCallback(this) { }
    }

    override fun onStart() {
        super.onStart()
        AppRepository.addListener(repoListener)
    }

    override fun onStop() {
        AppRepository.removeListener(repoListener)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        applyAppearance()
        if (AppRepository.cached() == null) {
            AppRepository.load(this) { if (!isFinishing && !isDestroyed) bind() }
        } else {
            bind()
        }
        refreshWeather(false)
    }

    override fun onPause() {
        handler.removeCallbacks(saveNote)
        Prefs.note = notes.text.toString()
        super.onPause()
    }

    /** Нажатие кнопки «Домой», пока лаунчер уже открыт: вернуться к началу. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) {
            homeGrid.scrollToPosition(0)
            notes.clearFocus()
            currentFocus?.let {
                (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                    .hideSoftInputFromWindow(it.windowToken, 0)
            }
        }
    }

    // ---------------------------------------------------------------- UI

    private fun applyAppearance() {
        val style = Prefs.clockStyle.coerceIn(0, ClockStyles.fonts.size - 1)
        clockTime.typeface = Typeface.create(ClockStyles.fonts[style], Typeface.NORMAL)
        val pattern = if (Prefs.clock24h) "HH:mm" else "h:mm"
        clockTime.format24Hour = pattern
        clockTime.format12Hour = pattern

        clockDate.visibility = if (Prefs.showDate) View.VISIBLE else View.GONE
        clockDate.setTextColor(Prefs.accent)
        weatherTemp.setTextColor(Prefs.accent)

        weatherCard.glass(24f)
        notesCard.glass(24f)
        dockContainer.glass(32f)

        (homeGrid.layoutManager as GridLayoutManager).spanCount = Prefs.gridColumns
    }

    private fun bind() {
        val all = AppRepository.cached() ?: return
        if (!Prefs.firstRunDone && all.isNotEmpty()) applyDefaults(all)

        val byKey = all.associateBy { it.key }
        val dockApps = Prefs.dock.mapNotNull { byKey[it] }
        val homeApps = Prefs.home.mapNotNull { byKey[it] }

        (dock.layoutManager as GridLayoutManager).spanCount = max(1, dockApps.size)
        dockAdapter.submitList(dockApps)
        homeAdapter.submitList(homeApps)

        hint.visibility = if (homeApps.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun refreshWeather(force: Boolean) {
        weatherDesc.text = Prefs.weatherCity
        WeatherRepository.get(this, force) { w ->
            if (isDestroyed) return@get
            if (w == null) {
                weatherIcon.text = "☁️"
                weatherTemp.text = "—"
                weatherDesc.text = "Нет данных"
            } else {
                val (emoji, text) = WeatherRepository.describe(w.code)
                weatherIcon.text = emoji
                weatherTemp.text = "${w.temp}°"
                weatherDesc.text = "${w.city} · $text"
            }
        }
    }

    // ---------------------------------------------------------------- первая настройка

    /** Док: телефон, сообщения, браузер, камера (системные по умолчанию). Главный экран: первые 8 приложений. */
    private fun applyDefaults(all: List<AppInfo>) {
        val pm = packageManager
        fun resolve(intent: Intent): String? {
            val ri = pm.resolveActivity(intent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY) ?: return null
            val pkg = ri.activityInfo.packageName
            return all.firstOrNull { it.pkg == pkg }?.key
        }

        val dockKeys = listOfNotNull(
            resolve(Intent(Intent.ACTION_DIAL)),
            resolve(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING)),
            resolve(Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))),
            resolve(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
        ).distinct()

        Prefs.dock = dockKeys
        Prefs.home = all.filter { it.key !in dockKeys }.take(8).map { it.key }
        Prefs.firstRunDone = true
    }

    // ---------------------------------------------------------------- клики по иконкам

    private fun onAppClick(app: AppInfo, v: View) = AppActions.launch(this, app, v)

    private fun onHomeLongClick(app: AppInfo, v: View) =
        AppActions.menu(this, v, app, AppActions.Kind.HOME) { bind() }

    private fun onDockLongClick(app: AppInfo, v: View) =
        AppActions.menu(this, v, app, AppActions.Kind.DOCK) { bind() }

    // ---------------------------------------------------------------- жесты

    private val gestures by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {

            override fun onDown(e: MotionEvent) = true

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (isEmptySpot(e)) lockScreen()
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (isEmptySpot(e)) startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null || hit(notesCard, e1)) return false
                // если сетка сама умеет прокручиваться, вертикальный жест на ней — это скролл
                if (hit(homeGrid, e1) && (homeGrid.canScrollVertically(1) || homeGrid.canScrollVertically(-1))) {
                    return false
                }
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (abs(dy) > abs(dx) * 1.5f && abs(dy) > dp(80) && abs(vy) > dp(300)) {
                    if (dy < 0) openDrawer() else openNotifications()
                    return true
                }
                return false
            }
        })
    }

    private fun dp(v: Float) = resources.displayMetrics.density * v

    /** Слушаем касания, но не перехватываем их — RecyclerView и EditText работают как обычно. */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun hit(v: View, e: MotionEvent): Boolean {
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        return e.rawX >= loc[0] && e.rawX <= loc[0] + v.width &&
            e.rawY >= loc[1] && e.rawY <= loc[1] + v.height
    }

    /** Пустое место = не иконка, не док и не поле заметок. */
    private fun isEmptySpot(e: MotionEvent): Boolean {
        if (hit(notesCard, e) || hit(dockContainer, e)) return false
        val loc = IntArray(2)
        homeGrid.getLocationOnScreen(loc)
        val child = homeGrid.findChildViewUnder(e.rawX - loc[0], e.rawY - loc[1])
        return child == null
    }

    private fun openDrawer() {
        startActivity(Intent(this, AppDrawerActivity::class.java))
    }

    @SuppressLint("WrongConstant", "PrivateApi")
    private fun openNotifications() {
        try {
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager")
                .getMethod("expandNotificationsPanel")
                .invoke(sb)
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось открыть шторку на этой версии Android", Toast.LENGTH_SHORT).show()
        }
    }

    private fun lockScreen() {
        val dpm = getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(this, MizanDeviceAdmin::class.java)
        if (dpm.isAdminActive(admin)) {
            dpm.lockNow()
        } else {
            startActivity(
                Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                    .putExtra(
                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "Нужно только для блокировки экрана двойным тапом."
                    )
            )
        }
    }
}
