package com.mizan.launcher

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        sp = ctx.applicationContext.getSharedPreferences("mizan", Context.MODE_PRIVATE)
    }

    // ---- Внешний вид ----
    var glassAlpha: Int
        get() = sp.getInt("glass_alpha", 22)
        set(v) = sp.edit().putInt("glass_alpha", v).apply()

    var accent: Int
        get() = sp.getInt("accent", 0xFF7CC4FF.toInt())
        set(v) = sp.edit().putInt("accent", v).apply()

    var gridColumns: Int
        get() = sp.getInt("grid_cols", 4)
        set(v) = sp.edit().putInt("grid_cols", v).apply()

    // ---- Часы ----
    var clockStyle: Int
        get() = sp.getInt("clock_style", 1)
        set(v) = sp.edit().putInt("clock_style", v).apply()

    var clock24h: Boolean
        get() = sp.getBoolean("clock_24h", true)
        set(v) = sp.edit().putBoolean("clock_24h", v).apply()

    var showDate: Boolean
        get() = sp.getBoolean("show_date", true)
        set(v) = sp.edit().putBoolean("show_date", v).apply()

    // ---- Погода и заметки ----
    var weatherCity: String
        get() = sp.getString("weather_city", "Москва") ?: ""
        set(v) = sp.edit().putString("weather_city", v).apply()

    var weatherCache: String
        get() = sp.getString("weather_cache", "") ?: ""
        set(v) = sp.edit().putString("weather_cache", v).apply()

    var weatherTime: Long
        get() = sp.getLong("weather_time", 0L)
        set(v) = sp.edit().putLong("weather_time", v).apply()

    var note: String
        get() = sp.getString("note", "") ?: ""
        set(v) = sp.edit().putString("note", v).apply()

    // ---- Меню приложений ----
    var drawerGrid: Boolean
        get() = sp.getBoolean("drawer_grid", true)
        set(v) = sp.edit().putBoolean("drawer_grid", v).apply()

    var drawerByCategory: Boolean
        get() = sp.getBoolean("drawer_by_category", true)
        set(v) = sp.edit().putBoolean("drawer_by_category", v).apply()

    var iconPack: String
        get() = sp.getString("icon_pack", "") ?: ""
        set(v) = sp.edit().putString("icon_pack", v).apply()

    var hidden: Set<String>
        get() = sp.getStringSet("hidden", emptySet())?.toSet() ?: emptySet()
        set(v) = sp.edit().putStringSet("hidden", v).apply()

    // ---- Списки приложений: «pkg/cls», по одному на строку ----
    var home: List<String>
        get() = getList("home")
        set(v) = putList("home", v)

    var dock: List<String>
        get() = getList("dock")
        set(v) = putList("dock", v)

    var recents: List<String>
        get() = getList("recents")
        set(v) = putList("recents", v)

    var firstRunDone: Boolean
        get() = sp.getBoolean("first_run_done", false)
        set(v) = sp.edit().putBoolean("first_run_done", v).apply()

    fun pushRecent(key: String) {
        val l = recents.toMutableList()
        l.remove(key)
        l.add(0, key)
        recents = l.take(12)
    }

    private fun getList(key: String): List<String> =
        (sp.getString(key, "") ?: "").split('\n').filter { it.isNotEmpty() }

    private fun putList(key: String, v: List<String>) {
        sp.edit().putString(key, v.joinToString("\n")).apply()
    }
}
