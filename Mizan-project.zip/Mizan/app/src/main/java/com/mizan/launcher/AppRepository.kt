package com.mizan.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.text.Collator
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

/**
 * Единый кэш списка приложений. Запрос к PackageManager выполняется один раз в фоне,
 * дальше все экраны читают готовый список из памяти. Сброс — по событиям установки/удаления.
 */
object AppRepository {
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var cache: List<AppInfo>? = null
    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    fun cached(): List<AppInfo>? = cache

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }

    /** Отдаёт список из кэша или загружает его в фоне. Колбэк вызывается в главном потоке. */
    fun load(ctx: Context, force: Boolean = false, cb: (List<AppInfo>) -> Unit) {
        val c = cache
        if (c != null && !force) {
            cb(c)
            return
        }
        val app = ctx.applicationContext
        io.execute {
            val list = query(app)
            cache = list
            main.post { cb(list) }
        }
    }

    /** Перечитать список и оповестить подписчиков (вызывается при установке/удалении пакетов). */
    fun refresh(ctx: Context) {
        load(ctx, force = true) { listeners.forEach { it() } }
    }

    @Suppress("DEPRECATION")
    private fun query(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val flags = PackageManager.MATCH_UNINSTALLED_PACKAGES

        val result = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(flags.toLong()))
        } else {
            pm.queryIntentActivities(intent, flags)
        }

        val collator = Collator.getInstance()
        return result.asSequence()
            .filter { it.activityInfo.packageName != ctx.packageName }
            // MATCH_UNINSTALLED_PACKAGES возвращает и «удалённые, но с сохранёнными данными» пакеты —
            // отсекаем всё, что реально не установлено, иначе иконка есть, а запуск падает
            .filter { it.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_INSTALLED != 0 }
            .map { ri ->
                val ai = ri.activityInfo
                val updated = try {
                    pm.getPackageInfo(ai.packageName, 0).lastUpdateTime
                } catch (e: Exception) {
                    0L
                }
                AppInfo(
                    pkg = ai.packageName,
                    cls = ai.name,
                    label = ri.loadLabel(pm).toString(),
                    category = categorize(ai.applicationInfo),
                    updated = updated
                )
            }
            .sortedWith { a, b -> collator.compare(a.label, b.label) }
            .toList()
    }

    private val COMM = listOf(
        "dialer", "contacts", "messaging", ".mms", "telegram", "whatsapp", "viber",
        "signal", "skype", "zoom", "teams", "gmail", ".email", ".mail", ".sms"
    )
    private val PHOTO = listOf("camera", "gallery", "photos")
    private val MEDIA = listOf("music", "video", "player", "youtube", "spotify", "podcast")

    @Suppress("DEPRECATION")
    private fun categorize(ai: ApplicationInfo): Category {
        val p = ai.packageName.lowercase()
        if (ai.category == ApplicationInfo.CATEGORY_GAME ||
            (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
        ) return Category.GAMES
        if (COMM.any { p.contains(it) }) return Category.COMM
        return when (ai.category) {
            ApplicationInfo.CATEGORY_SOCIAL -> Category.SOCIAL
            ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO -> Category.MEDIA
            ApplicationInfo.CATEGORY_IMAGE -> Category.PHOTO
            ApplicationInfo.CATEGORY_PRODUCTIVITY, ApplicationInfo.CATEGORY_NEWS,
            ApplicationInfo.CATEGORY_MAPS, ApplicationInfo.CATEGORY_ACCESSIBILITY -> Category.WORK
            else -> when {
                PHOTO.any { p.contains(it) } -> Category.PHOTO
                MEDIA.any { p.contains(it) } -> Category.MEDIA
                else -> Category.OTHER
            }
        }
    }
}
