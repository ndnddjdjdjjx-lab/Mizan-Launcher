package com.mizan.launcher

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import androidx.core.content.res.ResourcesCompat
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

/** Поддержка стандартных иконпаков (ADW / Nova / Go): читаем appfilter.xml и подбираем drawable. */
object IconPacks {
    data class Pack(val pkg: String, val label: String)

    private val ACTIONS = listOf(
        "org.adw.launcher.THEMES",
        "com.novalauncher.THEME",
        "com.gau.go.launcherex.theme"
    )

    fun installed(ctx: Context): List<Pack> {
        val pm = ctx.packageManager
        val seen = LinkedHashMap<String, Pack>()
        for (action in ACTIONS) {
            for (ri in pm.queryIntentActivities(Intent(action), 0)) {
                val pkg = ri.activityInfo.packageName
                seen[pkg] = Pack(pkg, ri.loadLabel(pm).toString())
            }
        }
        return seen.values.toList()
    }

    private val maps = HashMap<String, Map<String, String>>()

    @Synchronized
    private fun map(ctx: Context, pack: String): Map<String, String> =
        maps.getOrPut(pack) { parse(ctx, pack) }

    fun drawableFor(ctx: Context, pack: String, pkg: String, cls: String): Drawable? {
        val name = map(ctx, pack)["$pkg/$cls"] ?: return null
        return try {
            val res = ctx.packageManager.getResourcesForApplication(pack)
            val id = res.getIdentifier(name, "drawable", pack)
            if (id == 0) null else ResourcesCompat.getDrawable(res, id, null)
        } catch (e: Exception) {
            null
        }
    }

    private fun parse(ctx: Context, pack: String): Map<String, String> {
        val out = HashMap<String, String>()
        try {
            val res = ctx.packageManager.getResourcesForApplication(pack)
            val id = res.getIdentifier("appfilter", "xml", pack)
            val parser: XmlPullParser = if (id != 0) {
                res.getXml(id)
            } else {
                XmlPullParserFactory.newInstance().newPullParser().apply {
                    setInput(res.assets.open("appfilter.xml"), null)
                }
            }
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG && parser.name == "item") {
                    val comp = parser.getAttributeValue(null, "component")
                    val drawable = parser.getAttributeValue(null, "drawable")
                    if (comp != null && drawable != null &&
                        comp.startsWith("ComponentInfo{") && comp.endsWith("}")
                    ) {
                        val body = comp.substring(14, comp.length - 1)
                        val slash = body.indexOf('/')
                        if (slash > 0) {
                            val p = body.substring(0, slash)
                            var c = body.substring(slash + 1)
                            if (c.startsWith(".")) c = p + c
                            out["$p/$c"] = drawable
                        }
                    }
                }
                event = parser.next()
            }
        } catch (e: Exception) {
            // пак повреждён или не содержит appfilter — используем системные иконки
        }
        return out
    }
}
