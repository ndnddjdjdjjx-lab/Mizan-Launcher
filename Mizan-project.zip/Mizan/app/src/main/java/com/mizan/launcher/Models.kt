package com.mizan.launcher

import android.content.ComponentName
import android.content.Context
import android.view.View

enum class Category(val title: String) {
    GAMES("Игры"),
    COMM("Связь"),
    SOCIAL("Соцсети"),
    MEDIA("Медиа"),
    PHOTO("Фото и камера"),
    WORK("Работа и инструменты"),
    OTHER("Прочее")
}

data class AppInfo(
    val pkg: String,
    val cls: String,
    val label: String,
    val category: Category,
    val updated: Long
) {
    val key: String get() = "$pkg/$cls"
    val component: ComponentName get() = ComponentName(pkg, cls)
    fun icon() = AppIcon(pkg, cls, updated)
}

/** Данные, по которым Coil загружает иконку (ключ кэша = пакет + класс + версия + иконпак). */
data class AppIcon(val pkg: String, val cls: String, val updated: Long)

object ClockStyles {
    val names = arrayOf("Тонкий", "Лёгкий", "Обычный", "С засечками", "Моноширинный", "Узкий", "Рукописный")
    val fonts = arrayOf(
        "sans-serif-thin", "sans-serif-light", "sans-serif",
        "serif", "monospace", "sans-serif-condensed", "casual"
    )
}

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density

/** Применяет «стеклянный» фон с текущей прозрачностью из настроек. */
fun View.glass(radiusDp: Float) {
    background = GlassDrawable(context.dp(radiusDp), Prefs.glassAlpha)
}
