package com.mizan.launcher

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable

/**
 * Дешёвое «жидкое стекло»: тёмная подложка + светлая заливка + блик сверху + светлая кромка.
 * Рисуется тремя вызовами drawRoundRect без аллокаций и без шейдеров размытия — безопасно для Helio G200.
 * Реальный blur обоев делает окно меню приложений на Android 12+ (см. темы).
 */
class GlassDrawable(
    private val radius: Float,
    private val alphaPct: Int
) : Drawable() {

    private val rect = RectF()

    private val base = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb((alphaPct * 255 * 0.35f / 100f).toInt(), 0, 0, 0)
    }
    private val tint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(alphaPct * 255 / 100, 255, 255, 255)
    }
    private val shine = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
        color = Color.argb(80, 255, 255, 255)
    }

    override fun onBoundsChange(bounds: Rect) {
        rect.set(bounds)
        rect.inset(1f, 1f)
        shine.shader = LinearGradient(
            0f, bounds.top.toFloat(), 0f, bounds.bottom.toFloat(),
            Color.argb(70, 255, 255, 255), Color.TRANSPARENT,
            Shader.TileMode.CLAMP
        )
    }

    override fun draw(canvas: Canvas) {
        canvas.drawRoundRect(rect, radius, radius, base)
        canvas.drawRoundRect(rect, radius, radius, tint)
        canvas.drawRoundRect(rect, radius, radius, shine)
        canvas.drawRoundRect(rect, radius, radius, edge)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
