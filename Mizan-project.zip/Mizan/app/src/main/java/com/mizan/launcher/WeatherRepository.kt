package com.mizan.launcher

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

/** Погода через Open-Meteo (без ключа и без сторонних библиотек). Кэш на 30 минут. */
object WeatherRepository {
    data class Weather(val city: String, val temp: Int, val code: Int)

    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private const val TTL = 30 * 60 * 1000L
    private const val SEP = "\u0001"

    fun get(ctx: Context, force: Boolean, cb: (Weather?) -> Unit) {
        val query = Prefs.weatherCity.trim()
        val cached = readCache(query)
        val fresh = System.currentTimeMillis() - Prefs.weatherTime < TTL
        if (cached != null && fresh && !force) {
            cb(cached)
            return
        }
        if (cached != null) cb(cached) // сначала показываем старое, потом обновим

        io.execute {
            val w = try { fetch(query) } catch (e: Exception) { null }
            if (w != null) writeCache(query, w)
            main.post { cb(w ?: cached) }
        }
    }

    private fun fetch(city: String): Weather? {
        if (city.isEmpty()) return null
        val geo = JSONObject(
            httpGet(
                "https://geocoding-api.open-meteo.com/v1/search?name=" +
                    "${URLEncoder.encode(city, "UTF-8")}&count=1&language=ru&format=json"
            )
        )
        val r = geo.optJSONArray("results")?.optJSONObject(0) ?: return null
        val lat = r.getDouble("latitude")
        val lon = r.getDouble("longitude")
        val name = r.optString("name", city)

        val w = JSONObject(
            httpGet(
                "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weather_code"
            )
        )
        val cur = w.getJSONObject("current")
        return Weather(name, Math.round(cur.getDouble("temperature_2m")).toInt(), cur.getInt("weather_code"))
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun readCache(query: String): Weather? {
        val p = Prefs.weatherCache.split(SEP)
        if (p.size != 4 || p[0] != query) return null
        return try { Weather(p[1], p[2].toInt(), p[3].toInt()) } catch (e: Exception) { null }
    }

    private fun writeCache(query: String, w: Weather) {
        Prefs.weatherCache = listOf(query, w.city, w.temp, w.code).joinToString(SEP)
        Prefs.weatherTime = System.currentTimeMillis()
    }

    /** Эмодзи и описание по коду WMO. */
    fun describe(code: Int): Pair<String, String> = when (code) {
        0 -> "☀️" to "Ясно"
        1, 2 -> "🌤" to "Малооблачно"
        3 -> "☁️" to "Пасмурно"
        45, 48 -> "🌫" to "Туман"
        in 51..57 -> "🌦" to "Морось"
        in 61..67 -> "🌧" to "Дождь"
        in 71..77 -> "❄️" to "Снег"
        in 80..82 -> "🌧" to "Ливень"
        85, 86 -> "🌨" to "Снегопад"
        in 95..99 -> "⛈" to "Гроза"
        else -> "☁️" to "—"
    }
}
