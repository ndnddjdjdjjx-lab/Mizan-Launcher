package com.mizan.launcher

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class AppDrawerActivity : AppCompatActivity() {

    private lateinit var list: RecyclerView
    private lateinit var search: EditText
    private lateinit var adapter: DrawerAdapter

    private val handler = Handler(Looper.getMainLooper())
    private val rebuildTask = Runnable { rebuild() }
    private val repoListener: () -> Unit = { rebuild() }

    private val voice = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!text.isNullOrBlank()) search.setText(text)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_drawer)

        // Android 12+: если система разрешает размытие окон — тема уже включила blur.
        // Иначе делаем фон плотнее, чтобы текст читался.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val wm = getSystemService(android.view.WindowManager::class.java)
            if (!wm.isCrossWindowBlurEnabled) {
                window.setBackgroundDrawableResource(R.color.drawer_scrim)
            }
        }

        val root = findViewById<View>(R.id.drawer_root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }

        list = findViewById(R.id.app_list)
        search = findViewById(R.id.search)
        findViewById<View>(R.id.search_bar).glass(26f)

        val cols = if (Prefs.drawerGrid) Prefs.gridColumns else 1
        adapter = DrawerAdapter(
            grid = Prefs.drawerGrid,
            onClick = { app, v ->
                AppActions.launch(this, app, v)
                finish()
            },
            onLongClick = { app, v ->
                AppActions.menu(this, v, app, AppActions.Kind.DRAWER) { rebuild() }
            }
        )
        val lm = GridLayoutManager(this, cols)
        lm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int) =
                if (adapter.getItemViewType(position) == DrawerAdapter.HEADER) cols else 1
        }
        list.layoutManager = lm
        list.adapter = adapter
        list.itemAnimator = null
        list.setHasFixedSize(true)

        // Прячем клавиатуру при прокрутке
        list.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING) hideKeyboard()
            }
        })

        // Свайп вниз от верха списка закрывает меню
        val closer = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            private var atTop = false
            override fun onDown(e: MotionEvent): Boolean {
                atTop = !list.canScrollVertically(-1)
                return true
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 != null && atTop) {
                    val d = resources.displayMetrics.density
                    if (e2.y - e1.y > 120 * d && vy > 500 * d &&
                        Math.abs(e2.x - e1.x) < Math.abs(e2.y - e1.y)
                    ) {
                        finish()
                        return true
                    }
                }
                return false
            }
        })
        list.addOnItemTouchListener(object : RecyclerView.SimpleOnItemTouchListener() {
            override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean {
                closer.onTouchEvent(e)
                return false
            }
        })

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(rebuildTask)
                handler.postDelayed(rebuildTask, 100)
            }
        })
        search.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                val first = adapter.currentList.firstOrNull { it is Row.Item } as? Row.Item
                if (first != null) {
                    AppActions.launch(this, first.app, null)
                    finish()
                }
            }
            true
        }

        findViewById<ImageButton>(R.id.mic).setOnClickListener {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Название приложения")
            }
            try {
                voice.launch(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "Голосовой поиск недоступен на этом устройстве", Toast.LENGTH_SHORT).show()
            }
        }

        if (AppRepository.cached() == null) {
            AppRepository.load(this) { if (!isFinishing && !isDestroyed) rebuild() }
        } else {
            rebuild()
        }
    }

    override fun onStart() {
        super.onStart()
        AppRepository.addListener(repoListener)
    }

    override fun onStop() {
        AppRepository.removeListener(repoListener)
        super.onStop()
    }

    private fun rebuild() {
        val all = AppRepository.cached() ?: return
        adapter.submitList(
            DrawerBuilder.build(
                all = all,
                hidden = Prefs.hidden,
                recents = Prefs.recents,
                byCategory = Prefs.drawerByCategory,
                query = search.text.toString()
            )
        )
    }

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(search.windowToken, 0)
    }
}
