package com.mizan.launcher

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.appcompat.widget.PopupMenu

object AppActions {
    enum class Kind { DRAWER, HOME, DOCK }

    const val DOCK_MAX = 5

    fun launch(ctx: Context, app: AppInfo, from: View?) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val options = from?.let {
            ActivityOptions.makeScaleUpAnimation(it, 0, 0, it.width, it.height).toBundle()
        }
        try {
            ctx.startActivity(intent, options)
            Prefs.pushRecent(app.key)
        } catch (e: Exception) {
            Toast.makeText(ctx, "Не удалось открыть ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    fun menu(ctx: Context, anchor: View, app: AppInfo, kind: Kind, changed: () -> Unit) {
        val popup = PopupMenu(ctx, anchor)
        val m = popup.menu
        when (kind) {
            Kind.DRAWER -> {
                m.add(0, 1, 0, "На главный экран")
                m.add(0, 2, 1, "В док")
                m.add(0, 3, 2, "Скрыть")
            }
            Kind.HOME -> {
                m.add(0, 4, 0, "Убрать с экрана")
                m.add(0, 2, 1, "В док")
            }
            Kind.DOCK -> m.add(0, 5, 0, "Убрать из дока")
        }
        m.add(0, 6, 10, "О приложении")
        m.add(0, 7, 11, "Удалить")

        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> Prefs.home = (Prefs.home + app.key).distinct()
                2 -> {
                    val d = Prefs.dock
                    if (app.key !in d) {
                        if (d.size >= DOCK_MAX) {
                            Toast.makeText(ctx, "Док заполнен (максимум $DOCK_MAX)", Toast.LENGTH_SHORT).show()
                        } else {
                            Prefs.dock = d + app.key
                        }
                    }
                }
                3 -> Prefs.hidden = Prefs.hidden + app.key
                4 -> Prefs.home = Prefs.home - app.key
                5 -> Prefs.dock = Prefs.dock - app.key
                6 -> ctx.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", app.pkg, null))
                )
                7 -> ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
            }
            changed()
            true
        }
        popup.show()
    }
}
