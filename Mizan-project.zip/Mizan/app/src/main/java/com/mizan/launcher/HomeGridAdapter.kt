package com.mizan.launcher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load

object AppDiff : DiffUtil.ItemCallback<AppInfo>() {
    override fun areItemsTheSame(a: AppInfo, b: AppInfo) = a.key == b.key
    override fun areContentsTheSame(a: AppInfo, b: AppInfo) = a == b
}

/** Сетка приложений на главном экране. */
class HomeGridAdapter(
    private val onClick: (AppInfo, View) -> Unit,
    private val onLongClick: (AppInfo, View) -> Unit
) : ListAdapter<AppInfo, HomeGridAdapter.VH>(AppDiff) {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app_grid, parent, false)
        val vh = VH(v)
        v.setOnClickListener {
            val p = vh.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(getItem(p), v)
        }
        v.setOnLongClickListener {
            val p = vh.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onLongClick(getItem(p), v)
            true
        }
        return vh
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = getItem(position)
        holder.label.text = app.label
        holder.icon.load(app.icon())
    }
}
