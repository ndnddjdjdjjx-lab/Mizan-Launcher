package com.mizan.launcher

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import coil.ImageLoader
import coil.decode.DataSource
import coil.fetch.DrawableResult
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.key.Keyer
import coil.request.Options
import java.io.File
import java.io.FileOutputStream

/**
 * Двухуровневый кэш иконок:
 *  1) память — Coil (MemoryCache, ключ из AppIconKeyer);
 *  2) диск — маленькие PNG в cacheDir/icons. Дорогой рендер adaptive-иконки делается один раз.
 */
object IconRender {
    private const val SIZE_DP = 56f

    fun sizePx(ctx: Context): Int = ctx.dp(SIZE_DP).toInt()

    private fun dir(ctx: Context): File = File(ctx.cacheDir, "icons").apply { mkdirs() }

    fun bitmapFor(ctx: Context, icon: AppIcon): Bitmap {
        val size = sizePx(ctx)
        val pack = Prefs.iconPack
        val name = "${icon.pkg}_${icon.cls.hashCode()}_${pack.hashCode()}_${icon.updated}_$size.png"
        val file = File(dir(ctx), name)

        if (file.exists()) {
            BitmapFactory.decodeFile(file.path)?.let { return it }
        }

        val drawable = loadDrawable(ctx, icon, pack)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        if (drawable is AdaptiveIconDrawable) {
            // Adaptive-иконка рисует маску в центральных 72/108 области — растягиваем, чтобы форма заняла весь квадрат
            val pad = size / 4
            drawable.setBounds(-pad, -pad, size + pad, size + pad)
        } else {
            drawable.setBounds(0, 0, size, size)
        }
        drawable.draw(canvas)

        try {
            FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } catch (e: Exception) {
            // кэш необязателен
        }
        return bmp
    }

    private fun loadDrawable(ctx: Context, icon: AppIcon, pack: String): Drawable {
        if (pack.isNotEmpty()) {
            IconPacks.drawableFor(ctx, pack, icon.pkg, icon.cls)?.let { return it }
        }
        return try {
            ctx.packageManager.getActivityIcon(ComponentName(icon.pkg, icon.cls))
        } catch (e: Exception) {
            ctx.packageManager.defaultActivityIcon
        }
    }

    fun clear(ctx: Context) {
        dir(ctx).listFiles()?.forEach { it.delete() }
    }
}

class AppIconKeyer : Keyer<AppIcon> {
    override fun key(data: AppIcon, options: Options): String =
        "${data.pkg}/${data.cls}/${data.updated}/${Prefs.iconPack}"
}

class AppIconFetcher(
    private val ctx: Context,
    private val data: AppIcon
) : Fetcher {

    override suspend fun fetch(): FetchResult = DrawableResult(
        drawable = BitmapDrawable(ctx.resources, IconRender.bitmapFor(ctx, data)),
        isSampled = false,
        dataSource = DataSource.DISK
    )

    class Factory(private val ctx: Context) : Fetcher.Factory<AppIcon> {
        override fun create(data: AppIcon, options: Options, imageLoader: ImageLoader): Fetcher =
            AppIconFetcher(ctx, data)
    }
}
