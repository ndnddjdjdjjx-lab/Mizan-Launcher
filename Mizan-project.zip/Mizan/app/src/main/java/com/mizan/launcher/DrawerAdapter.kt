package com.mizan.launcher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load

/** Строка меню приложений: заголовок раздела или приложение. */
sealed class Row {
    abstract val id: String

    data class Header(val title: String) : Row() {
        override val id: String get() = "h:$title"
    }

    /** section нужен, чтобы одно приложение в «Недавних» и в своей категории имело разные id для DiffUtil. */
    data class Item(val app: AppInfo, val section: String) : Row() {
        override val id: String get() = "$section/${app.key}"
    }
}

object DrawerBuilder {
    fun build(
        all: List<AppInfo>,
        hidden: Set<String>,
        recents: List<String>,
        byCategory: Boolean,
        query: String
    ): List<Row> {
        val visible = all.filter { it.key !in hidden }

        if (query.isNotBlank()) {
            val q = query.trim().lowercase()
            return visible.filter { it.label.lowercase().contains(q) }.map { Row.Item(it, "s") }
        }

        val rows = ArrayList<Row>(visible.size + 12)
        if (byCategory) {
            val byKey = visible.associateBy { it.key }
            val rec = recents.mapNotNull { byKey[it] }.take(8)
            if (rec.isNotEmpty()) {
                rows += Row.Header("Недавние")
                rec.forEach { rows += Row.Item(it, "r") }
            }
            val groups = visible.groupBy { it.category }
            for (c in Category.values()) {
                val g = groups[c] ?: continue
                rows += Row.Header(c.title)
                g.forEach { rows += Row.Item(it, c.name) }
            }
        } else {
            for ((letter, apps) in visible.groupBy { letterOf(it.label) }) {
                rows += Row.Header(letter)
                apps.forEach { rows += Row.Item(it, "a") }
            }
        }
        return rows
    }

    private fun letterOf(label: String): String {
        val ch = label.trim().firstOrNull()?.uppercaseChar() ?: return "#"
        return if (ch.isLetter()) ch.toString() else "#"
    }
}

class DrawerAdapter(
    private val grid: Boolean,
    private val onClick: (AppInfo, View) -> Unit,
    private val onLongClick: (AppInfo, View) -> Unit
) : ListAdapter<Row, RecyclerView.ViewHolder>(DIFF) {

    companion object {
        const val HEADER = 0
        const val GRID = 1
        const val LIST = 2

        val DIFF = object : DiffUtil.ItemCallback<Row>() {
            override fun areItemsTheSame(a: Row, b: Row) = a.id == b.id
            override fun areContentsTheSame(a: Row, b: Row) = a == b
        }
    }

    class HeaderVH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v as TextView
    }

    class AppVH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
    }

    override fun getItemViewType(position: Int): Int = when (getItem(position)) {
        is Row.Header -> HEADER
        is Row.Item -> if (grid) GRID else LIST
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        if (viewType == HEADER) {
            return HeaderVH(inflater.inflate(R.layout.item_header, parent, false))
        }
        val layout = if (viewType == GRID) R.layout.item_app_grid else R.layout.item_app_list
        val v = inflater.inflate(layout, parent, false)
        val vh = AppVH(v)
        v.setOnClickListener {
            val p = vh.bindingAdapterPosition
            val row = if (p != RecyclerView.NO_POSITION) getItem(p) else null
            if (row is Row.Item) onClick(row.app, v)
        }
        v.setOnLongClickListener {
            val p = vh.bindingAdapterPosition
            val row = if (p != RecyclerView.NO_POSITION) getItem(p) else null
            if (row is Row.Item) onLongClick(row.app, v)
            true
        }
        return vh
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = getItem(position)) {
            is Row.Header -> {
                val h = holder as HeaderVH
                h.title.text = row.title
                h.title.setTextColor(Prefs.accent)
            }
            is Row.Item -> {
                val h = holder as AppVH
                h.label.text = row.app.label
                h.icon.load(row.app.icon())
            }
        }
    }
}
